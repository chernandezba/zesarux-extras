Vecchio utilizzo con lettura da ROM mediante la funzione LOADROM (USR 14500):


Inizialmente pensato per testare la batteria in tampone della RAM non volatile, NONVOLA.ASM si e` rivelato
molto utile anche per testare la SD CARD.

Effettua infatti una copia completa di 512K su un settore molto avanti della card (dopo i primi 256MB) per poi
permettere la verifica in un secondo tempo, magari dopo aver spento la macchina.

E` stato memorizzato in FLASHROM sul banco 12 (il n.11 0-based) e puo` essere richiamato senza caricarlo da
nastro mediante la funzione "LOADROM" inserita nella rom patchata (quella con l'incremento della prima locazione
video nell'handler NMI), generata dal programma 'FLASHROM.ASM'. Tale rom e` la n. 1 (la 0 e` il bootrom)
e puo` quindi essere richiamata mediante il primo tasto in alto a SX.

Fatto questo, per caricare il NONVOLA occorre:

CLEAR 29999
POKE 23728,11
RANDOMIZE USR 14500

A questo punto le funzioni sono disponibili dalla locazione 30000:

; 30.000:	Compare RAM against SD card. Returns number of mismatches (max 65535)
; 30.003:	Copy RAM to SD card
; 30.006:	Restore RAM from SD card
; 30.009:	TEST - COMPLEMENTS THE ENTIRE 512K RAM CONTENT

NOTARE che la presente versione gestisce DUE diverse posizioni di salvataggio in CARD; la prima
all'indirizzo sopraindicato (+256MB) e la seconda piu` avanti di 512K (quindi "sporchiamo" 1MB),
selezionabili mediante POKE 23728 (0 o 1).

La scelta dei banchi avviene mediante poke 23728: 0 = banco 0; 1 = banco 1.
