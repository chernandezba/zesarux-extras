Questa BOOTROM puo` essere programmata nel primo banco di FLASH ROM (0), attivabile al power-on mediante il dip-switch.

La versione attuale permette poi di selezionare una ROM, un banco RAM o la rom interna sinclair.

Il primo banco di RAM corrisponde normalmente al ResiDOS.


TEST:

Il comando JOIN crea un file TAP uploadabile direttamente (lanciare in 30000) che permette di testare la bootrom
senza programmarla nella flash. In testa viene infatti inserito un HEADER che provvede a copiare il codice macchina
nel banco RAM n. 31 (l'ultimo) per poi saltarvi. In questo modo e` possibile valutarne la funzionalita`.



PROGRAMMAZIONE IN FLASH:

Il file ROMIMAGE.BIN e` quello che puo` essere programmato nella ROM e comprende BOOTROM.ASM + FONT.BIN.
Dato che al momento l'unico modo per trasferirlo e` via TAPE, il programma HEADER.ASM provvede un secondo entry
point (indirizzo 40100) che utilizza le routines sperimentate in FLASHROM.ASM per programmare il chip.

La programmazione avviene sempre sul primo banco di ROM; gli altri sono preservati.


NOTA: Questa versione dispone di un handler NMI che si aggancia a quello della ROM PATCHATA:
Il programma MKSINCLA.ASM genera una ROM partendo dalla originale Sinclair presente dentro allo Spectrum 48K
che ha una modifica all'handler NMI: esegue uno switch di banco --> 0 in modo da proseguire l'esecuzione
nella presente BOOTROM. MKSINCLA.ASM stesso provvede alla programmazione di questa ROM nel BANCO 1.

Quindi:
BANCO 0 = BOOTROM (avvio al poweron con menu`, NMI handler)
BANCO 1 = PATCHED ROM the salta nella BOOTROM se arriva un NMI.

Al momento non c'e' modo di far funzionare l'NMI handler di una eventuale BOOTROM IN DEBUG SUL RAM-BANK 31.

La BOOTROM ha un NMI handler che, oltre a ricevere "l'aggancio" dalla patched rom, provvede ad accorgersi
se un NMI e` arrivato mentre era gia` attiva (in questo caso vengono eseguiti i primi bytes dell'handler presente
nella BOOTROM stessa, cosa che normalmente non accade perche` quello nella PATCHED ROM impiega 5 bytes per
eseguire lo switch verso di noi). Se cio` si verifica, provvede a caricare un valore in 'A' che servira` in uscita
per evitare di saltare nella patched ROM (cosa che normalmente deve avvenire per terminare l'NMI handler) ma
bensi` restare nella BOOTROM.

NOTA:
Probabilmente occorrera` trovare il modo di trasferire l'esecuzione della BOOTROM in RAM, ad esempio sul banco 31,
perche` questo e` l'unico modo per avere una zona RD/WR (in realta` tutto il banco da 16K diventa RD/WR).
Si potrebbe fare in modo che la BOOTROM stessa, al power-on, si auto-copi in RAM BANK 31 e continui la propria
esecuzione da la`. In questo caso, il MKSINCLAIR.ASM dovra` essere modificato in modo da saltare sul banco RAM 31
invece del banco ROM 0.
