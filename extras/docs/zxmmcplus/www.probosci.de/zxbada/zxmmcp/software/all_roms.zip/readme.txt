File B23.bin contains 32K to be flashed on banks 2,3 (16/48K rom)

File B4567.bin contains 64K to be flashed on banks 4,5,6,7 (IF1 and 128K roms)

File B89A.bin contains 48K to be flashed on banks 8,9,10 (BBC basic and utility rom)

ZX-Com and the current release of bootrom firmware are capable of handling multiple rom
flashing in one shot. For example, to flash banks 4,5,6,7 just go to Flash -> Flash ROM
zx-com menu, open the B4567.bin file, choose BANK 4 as destination and press OK.

All four banks will be sent and flashed.
